	
<?php
$server = "localhost";
$username = "root";
$password = "";
$database = "dbplesir";


$con = mysqli_connect($server,$username,$password,$database);
?>